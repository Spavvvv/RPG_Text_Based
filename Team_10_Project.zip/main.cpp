#include <iostream>
#include "GameSystem.h"

using namespace std;

int main() {

	GameSystem* gameSystem = new GameSystem;
	gameSystem->mainMenu();
	return 0;
}